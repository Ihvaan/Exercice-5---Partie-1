// car-table.component.ts
import { Component } from '@angular/core';
import { Car } from './car.model';

@Component({
  selector: 'app-car-table',
  templateUrl: './car-table-component.html',
})
export class CarTableComponent {
  cars: Car[] = [
    { id: 0, marque: 'Porsche', modele: 'Cayenne' },
    { id: 1, marque: 'Lamborghini', modele: 'Aventador' },
    { id: 2, marque: 'Ferrari', modele: 'F40' },
    { id: 3, marque: 'Porsche', modele: 'GT3RS' },
  ];

  selectedCar: Car = this.cars[0];

  showDetails(car: Car): void {
    this.selectedCar = car;
  }
}
