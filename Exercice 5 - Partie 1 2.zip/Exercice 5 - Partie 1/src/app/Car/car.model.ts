export interface Car {
  id: number;
  marque: string;
  modele: string;
}


